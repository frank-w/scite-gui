/*
SidebarTest
*/
/* lua_pushinteger(L,sbx);
 lua_pushnil(L);
*/
#define LUA_CORE

#include "lua.h"
#include "lauxlib.h"

#include "ldebug.h"
#include "lobject.h"
#include "lstate.h"

#include <gtk/gtk.h>

int SidebarHandle;
/*
void OutputMessage(lua_State *L)
{
	if (lua_isstring(L,-1)) {
		size_t len;
		const char *msg = lua_tolstring(L,-1,&len);
		char *buff = new char[len+2];
		strncpy(buff,msg,len);
		buff[len] = '\n';
		buff[len+1] = '\0';
		lua_pop(L,1);
		if (lua_checkstack(L,3)) {
			lua_getglobal(L,"output");
			lua_getfield(L,-1,"AddText");
			lua_insert(L,-2);
			lua_pushstring(L,buff);
			lua_pcall(L,2,0,0);
		}
		delete[] buff;
	}
}*/

static int do_SetSidebarHandle(lua_State *L)
{
 SidebarHandle=luaL_checkinteger(L,1);
 g_print("Sidebar-Handle: %d",SidebarHandle);
 lua_pushnumber(L,SidebarHandle);
 return 1;
}

static int do_PageControlAddPage(lua_State *L)
{

 return 1;
}

static const luaL_reg R[] =
{
  { "SetSidebarHandle", do_SetSidebarHandle},
	{ "Pagecontrol_Add_Page",	do_PageControlAddPage },
	{ NULL,			NULL	}
};

LUALIB_API int luaopen_gui(lua_State *L)
{
 luaL_register(L,"gui",R);
 return 1;
}
