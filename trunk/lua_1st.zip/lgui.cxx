/*
SidebarTest
*/
/* lua_pushinteger(L,sbx);
 lua_pushnil(L);
*/
#define LUA_CORE

extern "C" {
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
}

#include <gtk/gtk.h>

int SidebarHandle;

static int do_SetSidebarHandle(lua_State *L)
{
 SidebarHandle=luaL_checkinteger(L,1);
 g_print("Sidebar-Handle: %d",SidebarHandle);
 lua_pushnumber(L,SidebarHandle);
 return 1;
}

static int do_PageControlAddPage(lua_State *L)
{

 return 1;
}

static const luaL_reg R[] =
{
  { "SetSidebarHandle", do_SetSidebarHandle},
	{ "Pagecontrol_Add_Page",	do_PageControlAddPage },
	{ NULL,			NULL	}
};

extern "C" {//__declspec(dllexport)
LUALIB_API int luaopen_gui(lua_State *L)
{
 luaL_register(L,"gui",R);
 return 1;
}
}
