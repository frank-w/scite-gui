/*
SidebarTest
*/
/* lua_pushinteger(L,sbx);
 lua_pushnil(L);
*/
#define LUA_CORE

extern "C" {
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
}

#include <gtk/gtk.h>
#include <stdint.h>

int SidebarHandle;

int free_children(GtkContainer *c)
{
  GList *List = gtk_container_get_children (c);

  for (int i=g_list_length(List)-1;i>=0;i--)
  {
    GtkWidget *w = GTK_WIDGET(g_list_nth( List, i )->data);
    gtk_widget_destroy(w);
  }
}

static int do_InitSidebar(lua_State *L)
{
 SidebarHandle=luaL_checkinteger(L,1);
 g_print("Sidebar-Handle: 0x%x\n",SidebarHandle);
 
 free_children(GTK_CONTAINER(SidebarHandle));
 return 1;
}

static int do_PageControlAddPage(lua_State *L)
{
 int iPageControl=luaL_checkinteger(L,1);
 const char *caption=luaL_checkstring(L,2);
 
 g_print("Adding Page To Pagecontrol (0x%x) with label '%s'...\n",iPageControl,caption);

 GtkWidget *label=gtk_accel_label_new(caption);
 GtkWidget *vbox=gtk_vbox_new(2,false);
 gtk_widget_show(vbox);
 gtk_notebook_insert_page(GTK_NOTEBOOK(iPageControl),vbox,label,-1);
 
 lua_pushinteger(L,int(vbox));//put handle of content to stack
 return 1;//return 1 value (handle)
}

static const luaL_reg R[] =
{
  { "InitSidebar", do_InitSidebar},
	{ "Pagecontrol_Add_Page",	do_PageControlAddPage },
	{ NULL,			NULL	}
};

extern "C" {//__declspec(dllexport)
LUALIB_API int luaopen_gui(lua_State *L)
{
 luaL_register(L,"gui",R);
 return 1;
}
}
